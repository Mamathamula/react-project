import React from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.css'
export default function Footer()
{
    return(
        <div>
      <div className="row">
                            <div className="col-md-12 p-3 bg-dark text-light text-center"> hello </div>
                        </div>
    </div>
    )
}